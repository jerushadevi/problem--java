import java.util.Scanner;
public class Age